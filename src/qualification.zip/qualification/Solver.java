package qualification;

import qualification.bean.Book;
import qualification.bean.Input;
import qualification.bean.Library;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Solver {

    static List<Library> libraries;
    static List<Library> sortedLibraries;
    static Integer REMAIN_DAY;

    static List<Library> dynamicSortedLibrary;

    public static List<Library> solve(Input input) {
        libraries = new ArrayList<>();
        REMAIN_DAY = input.getDayCount();

        calculateScores(input.getLibraries());

        for (Library library :
                sortedLibraries) {

            if (library.getSignUpProcessDay() < REMAIN_DAY) {
                REMAIN_DAY -= library.getSignUpProcessDay();
//                library.setProcessedDay(library.getSignUpProcessDay() + library.getSignUpProcessDay());
                processLibrary(library);
            }

            List<Book> scannedBooks = library.getBooks().stream().filter(book -> book.getScanned().equals(Boolean.TRUE)).collect(Collectors.toList());
            if (!scannedBooks.isEmpty()) {
                libraries.add(library);
                calculateScores(sortedLibraries);
            }
        }

        return libraries;
    }

    private static void processLibrary(Library library) {
        List<Book> sortedBooks = library.getBooks().stream().sorted(Comparator.comparing(Book::getScore).reversed())
                .collect(Collectors.toList());
        library.setBooks(sortedBooks);

        Integer maxScanBook = REMAIN_DAY * library.getShippedBookCountPerDay();
        Integer scannedBookCount = 0;

        for (Book book :
                sortedBooks) {
            if (scannedBookCount <= maxScanBook) {
                book.setScanned(true);
            }
            scannedBookCount++;
        }

        //System.out.println(sortedBooks);
    }

    private static void calculateScores(List<Library> libraries) {
        libraries.forEach(library -> {
            List<Book> unscannedBooks = library.getBooks()
                    .stream().filter(book -> book.getScanned().equals(Boolean.FALSE))
                    .collect(Collectors.toList());

            Integer totalScore = 0;

            List<Integer> scores = unscannedBooks.stream().map(Book::getScore).collect(Collectors.toList());
            for (Integer score :
                    scores) {
                totalScore += score;
            }

            library.setTotalScore(totalScore);
            library.setValuePerDay(Double.valueOf(library.getTotalScore()) / library.getShippedBookCountPerDay());
            library.setFinalScore(library.getValuePerDay() - library.getSignUpProcessDay());

            Optional<Book> book = unscannedBooks.stream().sorted(Comparator.comparing(Book::getScore).reversed())
                    .findFirst();

            if (book.isPresent()) {
                library.setMaxScoredBook(book.get().getScore());
            } else {
                library.setMaxScoredBook(0);
            }

        });

        sortedLibraries = libraries.stream()
                .sorted(Comparator.comparing(Library::getFinalScore).reversed()
                        .thenComparing(Library::getShippedBookCountPerDay)
                        .thenComparing(Library::getMaxScoredBook))
                .collect(Collectors.toList());
    }
}
